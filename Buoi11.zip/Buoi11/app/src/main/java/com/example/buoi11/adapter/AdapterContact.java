package com.example.buoi11.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.buoi11.R;
import com.example.buoi11.entity.Contact;

import java.util.List;

public class AdapterContact extends ArrayAdapter<Contact> {
    private Context mCtx;
    private List<Contact> mList;

    public AdapterContact(@NonNull Context context, int resource, @NonNull List<Contact> objects) {
        super(context, R.layout.item_contact, objects);
        this.mCtx = context;
        this.mList = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if (v == null){
            v = LayoutInflater.from(this.mCtx).inflate(R.layout.item_contact, null);
        }
        Contact c = mList.get(position);
        TextView txtFullname = v.findViewById(R.id.itemFullname);
        TextView txtPhone = v.findViewById(R.id.itemPhone);
        TextView txtEmail = v.findViewById(R.id.itemEmail);

        ImageView btnUpdate = v.findViewById(R.id.itemBtnUpdate);
        ImageView btnDelete = v.findViewById(R.id.itemBtnDelete);

        txtFullname.setText(c.getFullname());
        txtPhone.setText(c.getPhone());
        txtEmail.setText(c.getEmail());

        return super.getView(position, convertView, parent);
    }
}
