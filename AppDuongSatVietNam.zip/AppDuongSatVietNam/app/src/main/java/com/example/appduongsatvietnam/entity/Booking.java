package com.example.appduongsatvietnam.entity;

import java.util.Date;

public class Booking {
    private int id;
    private String fullname;
    private String phone;
    private String fromStation;
    private String toStation;
    private boolean isOneWay;
    private Date startDate;
    private Date endDate;
    private int adult;
    private int baby;

    public Booking(int id, String fullname, String phone, String fromStation, String toStation, boolean isOneWay, Date startDate, Date endDate, int adult, int baby) {
        this.id = id;
        this.fullname = fullname;
        this.phone = phone;
        this.fromStation = fromStation;
        this.toStation = toStation;
        this.isOneWay = isOneWay;
        this.startDate = startDate;
        this.endDate = endDate;
        this.adult = adult;
        this.baby = baby;
    }

    public Booking(String fullname, String phone, String fromStation, String toStation, boolean isOneWay, Date startDate, Date endDate, int adult, int baby) {
        this.fullname = fullname;
        this.phone = phone;
        this.fromStation = fromStation;
        this.toStation = toStation;
        this.isOneWay = isOneWay;
        this.startDate = startDate;
        this.endDate = endDate;
        this.adult = adult;
        this.baby = baby;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFromStation() {
        return fromStation;
    }

    public void setFromStation(String fromStation) {
        this.fromStation = fromStation;
    }

    public String getToStation() {
        return toStation;
    }

    public void setToStation(String toStation) {
        this.toStation = toStation;
    }

    public boolean isOneWay() {
        return isOneWay;
    }

    public void setOneWay(boolean oneWay) {
        isOneWay = oneWay;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public int getAdult() {
        return adult;
    }

    public void setAdult(int adult) {
        this.adult = adult;
    }

    public int getBaby() {
        return baby;
    }

    public void setBaby(int baby) {
        this.baby = baby;
    }
}
