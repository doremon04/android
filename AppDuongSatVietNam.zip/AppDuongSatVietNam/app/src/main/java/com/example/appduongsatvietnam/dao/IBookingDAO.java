package com.example.appduongsatvietnam.dao;

import com.example.appduongsatvietnam.entity.Booking;

import java.util.List;

public interface IBookingDAO {
    public List<Booking> select();
    public Booking selectById(int id);
    public boolean insert(Booking booking);
    public boolean update(Booking booking);
    public boolean delete();
}
