package com.example.appduongsatvietnam.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "train.sqlite";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE tblBooking (\n" +
                "    id       INTEGER       PRIMARY KEY AUTOINCREMENT,\n" +
                "    fullname STRING        NOT NULL,\n" +
                "    phone    VARCHAR (11),\n" +
                "    fromStation    VARCHAR (255), \n" +
                "    toStation    VARCHAR (255), \n" +
                "    isOneWay    BIT, \n" +
                "    startDate    DATE, \n" +
                "    toDate    DATE, \n" +
                "    adult    INTEGER, \n" +
                "    baby    INTEGER \n" +
                ");\n";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
