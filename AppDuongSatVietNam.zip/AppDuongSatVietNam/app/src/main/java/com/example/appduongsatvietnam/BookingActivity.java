package com.example.appduongsatvietnam;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class BookingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        Button btnBooking = findViewById(R.id.formBtnBooking);
        btnBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fullName = ((EditText) findViewById(R.id.formFullName)).getText().toString();
                String phone = ((EditText) findViewById(R.id.formPhone)).getText().toString();
                String fromCity = ((Spinner) findViewById(R.id.spFromCity)).getSelectedItem().toString();
                String toCity = ((Spinner) findViewById(R.id.spToCity)).getSelectedItem().toString();
                boolean isOneWay = ((RadioButton) findViewById(R.id.radOneWay)).isChecked();
                String startDate = ((EditText) findViewById(R.id.startDate)).getText().toString();
                String endDate = ((EditText) findViewById(R.id.endDate)).getText().toString();
                String adult = ((EditText) findViewById(R.id.adult)).getText().toString();
                String baby = ((EditText) findViewById(R.id.baby)).getText().toString();

                Log.e("BKAP", "Họ tên: " + fullName);
                Log.e("BKAP", "SĐT: " + phone);
                Log.e("BKAP", "Ga đi: " + fromCity);
                Log.e("BKAP", "Ga đến: " + toCity);
                Log.e("BKAP", "Loại vé: " + (isOneWay ? "1 chiều" : "Khứ hồi"));
                Log.e("BKAP", "Ngày đi: " + startDate);
                Log.e("BKAP", "Ngày về: " + endDate);
                Log.e("BKAP", "Người lớn: " + adult);
                Log.e("BKAP", "Trẻ con: " + baby);
            }
        });
    }

    public void openDatePicker(View view) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);
                EditText edt = (EditText) view;
                SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
                edt.setText(fmt.format(calendar.getTime()));
            }
        };
        DatePickerDialog dpd = new DatePickerDialog(BookingActivity.this, listener, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        dpd.show();
    }
}