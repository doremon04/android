package com.example.appduongsatvietnam.dao;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.appduongsatvietnam.entity.Booking;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BookingDAOImpl implements IBookingDAO {
    private SQLiteDatabase mDB;

    public BookingDAOImpl(Context ctx) {
        DatabaseHelper helper = new DatabaseHelper(ctx);
        mDB = helper.getWritableDatabase();
    }

    @SuppressLint("Range")
    @Override
    public List<Booking> select() {
        String sql = "SELECT * FROM tblBooking";
        List<Booking> list = new ArrayList<>();
        Cursor c = mDB.rawQuery(sql, null);
        while (c.moveToNext()) {
            @SuppressLint("Range") int id = c.getInt(c.getColumnIndex("id"));
            @SuppressLint("Range") String fullname = c.getString(c.getColumnIndex("fullname"));
            @SuppressLint("Range") String phone = c.getString(c.getColumnIndex("phone"));
            @SuppressLint("Range") String fromStation = c.getString(c.getColumnIndex("fromStation"));
            @SuppressLint("Range") String toStation = c.getString(c.getColumnIndex("toStation"));
            @SuppressLint("Range") boolean isOneWay = c.getInt(c.getColumnIndex("isOneWay")) == 0;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date startDate = null;
            Date toDate = null;
            try {
                startDate = sdf.parse(c.getString(c.getColumnIndex("fromStation")));
                toDate = sdf.parse(c.getString(c.getColumnIndex("fromStation")));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            @SuppressLint("Range") int adult = c.getInt(c.getColumnIndex("adult"));
            @SuppressLint("Range") int baby = c.getInt(c.getColumnIndex("baby"));
            Booking booking = new Booking(id, fullname, phone, fromStation, toStation, isOneWay, startDate, toDate, adult, baby);
            list.add(booking);
        }
        return list;
    }

    @Override
    public Booking selectById(int id) {
        return null;
    }

    @Override
    public boolean insert(Booking booking) {
        return false;
    }

    @Override
    public boolean update(Booking booking) {
        return false;
    }

    @Override
    public boolean delete() {
        return false;
    }
}
